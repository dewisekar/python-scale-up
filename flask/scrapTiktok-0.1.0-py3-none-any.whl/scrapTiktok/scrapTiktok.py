import requests
from lxml import etree
from io import StringIO
import json
from datetime import datetime


def getIdFromLongUrl(url: str) -> dict:
        print("this is short url", url)       
        headers = {
            'authority' : 'tiktok.livecounts.io',
            'origin'    : 'https://livecounts.io',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',
        }
        # proxies = livecounts.__getProxies()
        # print(proxies)
        req = get(url, headers=headers, allow_redirects=False)
        print("status",req.status_code)  # 302
        print("url header", req.headers['Location'])

        return req.headers['Location']

def getUserInfo(username):
    userInfo = {}
    if username[0:1] != '@':
        username = '@' + username
    try:
        parser = etree.HTMLParser()
        headers = {
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',
        }
        page = requests.get(f'https://www.tiktok.com/{username}',headers=headers)
        html = page.content.decode("utf-8")
        tree = etree.parse(StringIO(html), parser=parser)
        id_path = "SIGI_STATE"
        results = tree.xpath("//script[@id = '%s']" % id_path)
        videoData = json.loads(results[0].text)
        userInfo['avatar'] = videoData['UserModule']['users'][username[1:len(username)]]['avatarThumb']
        userInfo['id'] = videoData['UserModule']['users'][username[1:len(username)]]['uniqueId']
        userInfo['userId'] = videoData['UserModule']['users'][username[1:len(username)]]['id']
        userInfo['username'] = videoData['UserModule']['users'][username[1:len(username)]]['nickname']
    except Exception as e:
        print('got exception getUserInfo, e:',e)
    return userInfo

def getUserStats(username):
    userStats = {}
    if username[0:1] != '@':
        username = '@' + username
    try:
        parser = etree.HTMLParser()
        headers = {
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',
        }
        page = requests.get(f'https://www.tiktok.com/{username}',headers=headers)
        html = page.content.decode("utf-8")
        tree = etree.parse(StringIO(html), parser=parser)
        id_path = "SIGI_STATE"
        results = tree.xpath("//script[@id = '%s']" % id_path)
        videoData = json.loads(results[0].text)
        userStats['followerCount'] = videoData['UserModule']['stats'][username[1:len(username)]]['followerCount']
        userStats['followingCount'] = videoData['UserModule']['stats'][username[1:len(username)]]['followingCount']
        userStats['likeCount'] = videoData['UserModule']['stats'][username[1:len(username)]]['heartCount']
        userStats['videoCount'] = videoData['UserModule']['stats'][username[1:len(username)]]['videoCount']
        userStats['success'] = True
        userStats['cache'] = True
    except Exception as e:
        print('got exception getUserStats, e:',e)
    return userStats


def getListVideoFromTiktokUser(username):
    listVideo = []
    if username[0:1] != '@':
        username = '@' + username
    try :
        parser = etree.HTMLParser()
        headers = {
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',
        }
        page = requests.get(f'https://www.tiktok.com/{username}',headers=headers)
        html = page.content.decode("utf-8")
        tree = etree.parse(StringIO(html), parser=parser)
        refs = tree.xpath("//a")
        links = [link.get('href', '') for link in refs]
        listVideo = [l.split("/")[5] for l in links if '/video/' in l][:10]
    except Exception as e:
        print('got exception getListVideoFromTiktokUser, e:',e)
    return listVideo

def getVideoStats(videoId,username):
    resp = {}
    if username[0:1] != '@':
        username = '@' + username
    try:
        parser = etree.HTMLParser()
        headers = {
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',
        }
        page = requests.get(f'https://www.tiktok.com/{username}/video/{videoId}',headers=headers)
        html = page.content.decode("utf-8")
        tree = etree.parse(StringIO(html), parser=parser)
        id_path = "SIGI_STATE"
        results = tree.xpath("//script[@id = '%s']" % id_path)
        videoData = json.loads(results[0].text)
        stats = videoData['ItemModule'][videoId]['stats']
        stats['cache'] = True
        resp = {'stats':{'cache':True,'commentCount':stats['commentCount'],'likeCount':stats['diggCount'],'shareCount':stats['shareCount'],'viewCount':stats['playCount']}}
    except Exception as e:
        print('got exception getCreatedTime, e:',e)
    return resp

    
def getVideoDataAndStats(videoId,username):
    resp = {}
    if username[0:1] != '@':
        username = '@' + username
    try:
        parser = etree.HTMLParser()
        headers = {
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',
        }
        page = requests.get(f'https://www.tiktok.com/{username}/video/{videoId}',headers=headers)
        html = page.content.decode("utf-8")
        tree = etree.parse(StringIO(html), parser=parser)
        id_path = "SIGI_STATE"
        results = tree.xpath("//script[@id = '%s']" % id_path)
        videoData = json.loads(results[0].text)
        unixTimeStamps = videoData['ItemModule'][videoId]['createTime']
        ts = int(unixTimeStamps)
        createTime = datetime.utcfromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
        data = {'cover:': videoData['ItemModule'][videoId]['video']['cover'],"title": videoData['SEOState']['metaParams']['title'],"createTime":createTime}
        stats = videoData['ItemModule'][videoId]['stats']
        resp = {'id':videoId,'data':data,'stats':stats}
    except Exception as e:
        print('got exception getCreatedTime, e:',e)
    return resp

